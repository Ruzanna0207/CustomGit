package com.customgit.presentation.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.customgit.R
import com.customgit.databinding.ActivityMainBinding
import com.customgit.presentation.auth.FragmentAuth

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportFragmentManager
            .beginTransaction().replace(R.id.frame, FragmentAuth.newInstance()).commit()
    }
}