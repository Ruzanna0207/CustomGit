package com.customgit.core.data_classes

data class TokensModel(
    val accessToken: String,
    val refreshToken: String,
    val idToken: String
)
