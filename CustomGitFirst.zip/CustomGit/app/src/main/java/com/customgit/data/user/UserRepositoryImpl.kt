package com.customgit.data.user

import com.customgit.core.data_classes.RemoteGithubUser
import com.customgit.core.data_classes.Repository
import com.customgit.data.auth.app_auth.AppAuth
import com.customgit.data.auth.app_auth.TokenStorage
import com.customgit.domain.api.GithubApi
import com.customgit.domain.user.UserRepository
import net.openid.appauth.EndSessionRequest

val token = TokenStorage.accessToken ?: ""

class UserRepositoryImpl : UserRepository {

    //фун-я для выхода
    override fun logout() {
        TokenStorage.accessToken = null
        TokenStorage.refreshToken = null
        TokenStorage.idToken = null
    }

    //выход из системы с использованием Custom Tabs
    override fun getEndSessionRequest(): EndSessionRequest {
        return AppAuth.getEndSessionRequest()
    }

    override suspend fun getUserInformation(): RemoteGithubUser {
        return GithubApi.INSTANCE.getCurrentUser()
    }

    override suspend fun getRepositories(): List<Repository> {
        return GithubApi.INSTANCE.getUserRepositories(token)
    }
}