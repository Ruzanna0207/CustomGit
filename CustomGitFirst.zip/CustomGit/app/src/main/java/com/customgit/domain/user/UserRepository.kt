package com.customgit.domain.user

import com.customgit.core.data_classes.RemoteGithubUser
import com.customgit.core.data_classes.Repository
import net.openid.appauth.EndSessionRequest

interface UserRepository {
    suspend fun getUserInformation(): RemoteGithubUser

    suspend fun getRepositories():  List<Repository>

    //функции для выхода
    fun logout()

    fun getEndSessionRequest(): EndSessionRequest
}
