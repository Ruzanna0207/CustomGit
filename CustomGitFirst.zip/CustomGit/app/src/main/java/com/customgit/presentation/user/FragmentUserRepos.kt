package com.customgit.presentation.user

import android.app.Activity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.bumptech.glide.Glide
import com.customgit.R
import com.customgit.adapters.Clickable
import com.customgit.adapters.RepositoriesAdapter
import com.customgit.core.data_classes.Repository
import com.customgit.core.utils.launchAndCollectIn
import com.customgit.databinding.FragmentUserReposBinding
import com.customgit.presentation.user.details.FragmentRepoDetails
import com.customgit.presentation.user.details.FragmentUserDetails
import com.customgit.viewModels.user_info.UserInfoViewModel

class FragmentUserRepos : Fragment(), Clickable {

    private val viewModel: UserInfoViewModel by viewModels()
    private lateinit var binding: FragmentUserReposBinding
    private var backButtonPressedTime: Long = 0
    private val backButtonInterval: Long = 2000

    private val logoutResponse = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            viewModel.webLogoutComplete()
        } else {
            viewModel.webLogoutComplete()
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentUserReposBinding.inflate(layoutInflater)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        getInfo()
        aboutUser()
        aboutRepos()
        clickToSeeDetailsUser()
        clickToBackAndExit()
        logOut()
    }


    companion object {
        fun newInstance2() = FragmentUserRepos()
    }

    private fun getInfo() = with(viewModel) {
        getUser()
        getAllRepos()
    }

    private fun aboutUser() = with(binding) {

        viewModel.currentUser.observe(viewLifecycleOwner) {

            Glide.with(requireContext())
                .load(it?.avatarUrl)
                .circleCrop()
                .into(image)

            userName.text = it.name
            userLocation.text = it.location
        }
    }

    private fun aboutRepos() = with(binding) {

        val adapter = RepositoriesAdapter(this@FragmentUserRepos)
        repositoriesRecView.adapter = adapter

        viewModel.currentRepos.observe(viewLifecycleOwner) { repos ->
            adapter.repos = repos
            adapter.notifyDataSetChanged()
        }
    }

    private fun clickToSeeDetailsUser() {
        //открытие фрагмента для просмотра инф-ии о пользователе
        binding.image.setOnClickListener {
            viewModel.currentUser.observe(viewLifecycleOwner) { user->
                val secondFragment = FragmentUserDetails()
                secondFragment.arguments = bundleOf("user" to user)

                requireActivity().supportFragmentManager.beginTransaction()
                    .add(R.id.frame, secondFragment)
                    .addToBackStack(null)
                    .commit()
            }
        }
    }

    override fun clickToSeeDetailsRepo(repo: Repository) {
        val secondFragment = FragmentRepoDetails()
        secondFragment.arguments = bundleOf("repo" to  repo)

        requireActivity().supportFragmentManager.beginTransaction()
            .add(R.id.frame, secondFragment)
            .addToBackStack(null)
            .commit()
    }

    private fun clickToBackAndExit() {
        //обработка двойного и одиночного нажатия кнопки назад
        val callback = object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val currentTime = System.currentTimeMillis()

                if (currentTime - backButtonPressedTime < backButtonInterval) {
                    requireActivity().finish()
                } else {
                    backButtonPressedTime = currentTime
                    // Здесь вы можете добавить обработку для одиночного нажатия, если необходимо
                    Toast.makeText(requireContext(), "Press back again to exit", Toast.LENGTH_SHORT).show()
                }
            }
        }
        requireActivity().onBackPressedDispatcher.addCallback(viewLifecycleOwner, callback)
    }

    private fun logOut() {
        viewModel.logoutPageFlow.launchAndCollectIn(viewLifecycleOwner) {
            logoutResponse.launch(it)
        }
        //разлогинится
        binding.exit.setOnClickListener {
           viewModel.logout()
        }
    }
}
