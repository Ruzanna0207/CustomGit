package com.customgit.domain.api

import com.customgit.core.data_classes.RemoteGithubUser
import com.customgit.core.data_classes.Repository
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Header

//https://api.github.com/users/ruzanna0207
//https://api.github.com/users/Ruzanna0207/repos


interface GithubApi {
    @GET("users/ruzanna0207")
    suspend fun getCurrentUser(): RemoteGithubUser

    @GET("users/ruzanna0207/repos")
    suspend fun getUserRepositories(@Header("Authorization") token: String): List<Repository>


//    companion object {
//
//        val INSTANCE: GithubApi = Retrofit.Builder()
//            .addConverterFactory(GsonConverterFactory.create())
//            .baseUrl("https://api.github.com/")
//            .build()
//            .create(GithubApi::class.java)
//    }
}
